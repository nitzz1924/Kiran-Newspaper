<a href="/">
    <img src="{{ asset('assets/images/news.jpg') }}" height="150px" width="150px" alt="..." >
</a>
